# FFOS app template

Firefox OS open web app template with localisation.

## Test with your device or simulator

* Download and install [Firefox Nightly](https://nightly.mozilla.org/)
* Firefox > Developer > WebIDE
* Select your device or simulator
* Open Hosted App
* URL to your `manifest.webapp`
* Run
